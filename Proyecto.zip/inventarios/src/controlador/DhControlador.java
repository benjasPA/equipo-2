package controlador;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Dh;
import comun.interfaces.ScreenControlable;
import datos.cdDh;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import vista.Main;

public class DhControlador implements ScreenControlable{
	private Main mainApp;
	private cdDh nuevoPrograma= new cdDh();
	private List<Dh> misprogramasa=new ArrayList<Dh>();
	Dh datosPrograma;
	
	@FXML
	TextField txtNombre;
	@FXML
	TextField txtId;
	@FXML
	Button btnGuardar;
	@FXML
	Button btnEliminar;
	@FXML
	Button btnActualizar;
	@FXML
	TableView<Dh> tvprogramas;
	@FXML
	TableColumn tcid;
	@FXML
	TableColumn tcnombre;
	
	@Override
	public void setMainApp(Main mainApp) {
		this.mainApp=mainApp;
	}
	
	@FXML
	public void initialize() {
		try {
			Llenar();
			btnActualizar.setDisable(true);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void Llenar() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{ 
		misprogramasa=nuevoPrograma.listar();
		ObservableList<Dh> data = FXCollections.observableArrayList(misprogramasa);
		 tcid.setCellValueFactory(new PropertyValueFactory<Dh,String>("id")); 
		 tcnombre.setCellValueFactory(new PropertyValueFactory<Dh,String>("nombre")); 
		 tvprogramas.setItems(data);
	}
	@FXML
	private void eliminar(ActionEvent event) {
		try {
			nuevoPrograma.eliminar(Integer.parseInt(txtId.getText()));
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FXML
	private void actualizar(ActionEvent event) {
		System.out.println(txtId.getText());
		System.out.println(txtNombre.getText());
		
		try {
			nuevoPrograma.actualizar(new Dh(txtId.getText(), txtNombre.getText()));
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	@FXML
	private void guardar(ActionEvent event) {
		try {
			System.out.println(txtId.getText());
			if(txtId.getText().equals("null")) {
				nuevoPrograma.agregar(new Dh(null, txtNombre.getText()));
				txtNombre.setText("");
			}else {
				nuevoPrograma.actualizar(new Dh(txtId.getText(), txtNombre.getText()));
				txtId.setText("null");
				txtNombre.setText("");
			}
			
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	@FXML
	private void seleccionar() {
		datosPrograma = (Dh) tvprogramas.getSelectionModel().getSelectedItem();
		txtNombre.setText(datosPrograma.getNombre());
		txtId.setText(datosPrograma.getId());
	}
	

}
