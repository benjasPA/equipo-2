package controlador;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Programa;
import comun.interfaces.ScreenControlable;
import datos.cdPrograma;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import vista.Main;

public class ProgramasControlador implements ScreenControlable{
	private Main mainApp;
	private cdPrograma nuevoPrograma= new cdPrograma();
	private List<Programa> misprogramasa=new ArrayList<Programa>();
	Programa datosPrograma;
	
	@FXML
	TextField txtNombre;
	@FXML
	TextField txtId;
	@FXML
	Button btnGuardar;
	@FXML
	Button btnEliminar;
	@FXML
	Button btnActualizar;
	@FXML
	TableView<Programa> tvprogramas;
	@FXML
	TableColumn tcid;
	@FXML
	TableColumn tcnombre;
	
	@Override
	public void setMainApp(Main mainApp) {
		this.mainApp=mainApp;
	}
	
	@FXML
	public void initialize() {
		try {
			Llenar();
			btnActualizar.setDisable(true);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void Llenar() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{ 
		misprogramasa=nuevoPrograma.listar();
		ObservableList<Programa> data = FXCollections.observableArrayList(misprogramasa);
		 tcid.setCellValueFactory(new PropertyValueFactory<Programa,String>("id")); 
		 tcnombre.setCellValueFactory(new PropertyValueFactory<Programa,String>("nombre")); 
		 tvprogramas.setItems(data);
	}
	@FXML
	private void eliminar(ActionEvent event) {
		try {
			nuevoPrograma.eliminar(Integer.parseInt(txtId.getText()));
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FXML
	private void actualizar(ActionEvent event) {
		System.out.println(txtId.getText());
		System.out.println(txtNombre.getText());
		
		try {
			nuevoPrograma.actualizar(new Programa(txtId.getText(), txtNombre.getText()));
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	@FXML
	private void guardar(ActionEvent event) {
		try {
			System.out.println(txtId.getText());
			if(txtId.getText().equals("null")) {
				nuevoPrograma.agregar(new Programa(null, txtNombre.getText()));
				txtNombre.setText("");
			}else {
				nuevoPrograma.actualizar(new Programa(txtId.getText(), txtNombre.getText()));
				txtId.setText("null");
				txtNombre.setText("");
			}
			
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	@FXML
	private void seleccionar() {
		datosPrograma = (Programa) tvprogramas.getSelectionModel().getSelectedItem();
		txtNombre.setText(datosPrograma.getNombre());
		txtId.setText(datosPrograma.getId());
	}
	

}
