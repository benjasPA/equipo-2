package controlador;

import comun.interfaces.ScreenControlable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import vista.Main;

public class MenuControlador implements ScreenControlable {
	private Main mainApp;
	
	@FXML
	Button btnNueva;
	@FXML
	Button btnPaciente;
	@FXML
	Button btnHistorial;
	@FXML
	Button btnDoctores;
	@FXML
	MenuItem mniProgramas;
	@FXML
	MenuItem mniAtencion;
	@FXML
	MenuItem mniControlPrenatal;
	@FXML
	MenuItem mniEstadoNutricion;
	@FXML
	MenuItem mniNivelNutricion;
	@FXML
	MenuItem mniTratamiento;
	@FXML
	MenuItem mniHidratacion;
	@FXML
	MenuItem mniDh;
	@FXML
	MenuItem mniMetodos;
	@FXML
	MenuItem mniDeteccion;
	@FXML
	MenuItem mniOtro;
	@FXML
	MenuItem mniEstado;
	@FXML
	MenuItem mniMunicipio;
	@FXML
	MenuItem mniLocalidad;
	@FXML
	MenuItem mniEnfermedades;
	
	

	


	
	@FXML
	private void programas(ActionEvent event) {
		mainApp.cargarVentana(Main.programas);
	}
	@FXML
	private void atencion(ActionEvent event) {
		mainApp.cargarVentana(Main.atencion);
	}
	@FXML
	private void controlprenatal(ActionEvent event) {
		mainApp.cargarVentana(Main.controlpre);
	}
	@FXML
	private void estadonutricion(ActionEvent event) {
		mainApp.cargarVentana(Main.estadonutricion);
	}
	@FXML
	private void nivel(ActionEvent event) {
		mainApp.cargarVentana(Main.nivel);
	}
	@FXML
	private void tratamiento(ActionEvent event) {
		mainApp.cargarVentana(Main.tratamiento);
	}
	@FXML
	private void hidratacion(ActionEvent event) {
		mainApp.cargarVentana(Main.hidratacion);
	}
	@FXML
	private void dh(ActionEvent event) {
		mainApp.cargarVentana(Main.dh);
	}
	@FXML
	private void metodos(ActionEvent event) {
		mainApp.cargarVentana(Main.metodos);
	}
	@FXML
	private void deteccion(ActionEvent event) {
		mainApp.cargarVentana(Main.deteccion);
	}
	@FXML
	private void otro(ActionEvent event) {
		mainApp.cargarVentana(Main.otro);
	}
	@FXML
	private void estado(ActionEvent event) {
		mainApp.cargarVentana(Main.estado);
	}
	@FXML
	private void municipio(ActionEvent event) {
		mainApp.cargarVentana(Main.municipio);
	}
	@FXML
	private void localidad(ActionEvent event) {
		mainApp.cargarVentana(Main.localidad);
	}
	@FXML
	private void enfermedades(ActionEvent event) {
		mainApp.cargarVentana(Main.enfermedades);
	}
	@FXML
	private void pacientes(ActionEvent event) {
		mainApp.cargarVentana(Main.pacientes);
	}
	

	@FXML
	private void doctores(ActionEvent event) {
		mainApp.cargarVentana(Main.doctores);
	}
    @FXML
	private void nueva(ActionEvent event) {
		mainApp.cargarVentana(Main.nueva);
	}
    @FXML
	private void historial(ActionEvent event) {
		mainApp.cargarVentana(Main.historial);
    }
   

	
	@Override
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
	}
	
}
