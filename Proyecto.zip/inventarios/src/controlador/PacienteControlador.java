package controlador;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import comun.entidades.Paciente;
import comun.interfaces.ScreenControlable;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import logica.clPaciente;
import vista.Main;

	public class PacienteControlador implements ScreenControlable {
	private Paciente datoUsuario;
	private Main mainApp;

	clPaciente nuevoUsuario = new clPaciente();
	List<Paciente> Usuarios= new ArrayList<Paciente>();
	
	@FXML
	Button btnNuevo, btnGuardar, btnEditar, btnEliminar, btnCancelar, btnRestaurar;
	
	@FXML
	TextField txtId, txtNombre, txtPaterno, txtMaterno, txtCurp, txtSexo, txtFecha, txtAfiliacion, txtEstado, txtMunicipio, txtLocalidad, txtIndigena, txtOportunidades;
	
	@FXML
	TableView<Paciente> tvPacientes;
	
	@FXML
	TableColumn tcId, tcNombre, tcPaterno, tcMaterno, tcCurp, tcClues, tcSexo, tcFecha, tcAfiliacion, tcEstado, tcMunicipio, tcLocalidad, tcIndigena, tcOportunidades; 
	
	
	public void initialize() {
		txtNombre.setDisable(true);
		txtPaterno.setDisable(true);
		txtMaterno.setDisable(true);
		txtCurp.setDisable(true);
		txtSexo.setDisable(true);
		txtFecha.setDisable(true);
		txtAfiliacion.setDisable(true);
		txtEstado.setDisable(true);
		txtMunicipio.setDisable(true);
		txtLocalidad.setDisable(true);
		txtIndigena.setDisable(true);
		txtOportunidades.setDisable(true);
		btnGuardar.setDisable(true);
		btnEliminar.setDisable(true);
		btnEditar.setDisable(true);
		try {
				Llenar();
			}catch (Exception e) {
				e.printStackTrace();
		}
	}
	
	@FXML
	public void Llenar() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
		Usuarios=nuevoUsuario.listar();
		ObservableList<Paciente> data=FXCollections.observableArrayList(Usuarios);
		tcId.setCellValueFactory(new PropertyValueFactory<Paciente,String>("id"));
		tcNombre.setCellValueFactory(new PropertyValueFactory<Paciente,String>("nombre"));
		tcPaterno.setCellValueFactory(new PropertyValueFactory<Paciente,String>("paterno"));
		tcMaterno.setCellValueFactory(new PropertyValueFactory<Paciente,String>("materno"));
		tcCurp.setCellValueFactory(new PropertyValueFactory<Paciente,String>("curp"));
		tcSexo.setCellValueFactory(new PropertyValueFactory<Paciente,String>("sexo"));
		tcFecha.setCellValueFactory(new PropertyValueFactory<Paciente,String>("fechaNacimiento"));
		tcAfiliacion.setCellValueFactory(new PropertyValueFactory<Paciente,String>("noAfiliacion"));
		tcEstado.setCellValueFactory(new PropertyValueFactory<Paciente,String>("estado"));
		tcMunicipio.setCellValueFactory(new PropertyValueFactory<Paciente,String>("municipio"));
		tcLocalidad.setCellValueFactory(new PropertyValueFactory<Paciente,String>("localidad"));
		tcIndigena.setCellValueFactory(new PropertyValueFactory<Paciente,String>("indigena"));
		tcOportunidades.setCellValueFactory(new PropertyValueFactory<Paciente,String>("oportunidades"));
		tvPacientes.setItems(data);
	}
	
	@FXML
	private void nuevo(ActionEvent event){
		txtNombre.setDisable(false);
		txtPaterno.setDisable(false);
		txtMaterno.setDisable(false);
		txtCurp.setDisable(false);
		txtSexo.setDisable(false);
		txtFecha.setDisable(false);
		txtAfiliacion.setDisable(false);
		txtEstado.setDisable(false);
		txtMunicipio.setDisable(false);
		txtLocalidad.setDisable(false);
		txtIndigena.setDisable(false);
		txtOportunidades.setDisable(false);
		btnNuevo.setDisable(true);
		btnGuardar.setDisable(false);
		btnEditar.setDisable(true);
		btnEliminar.setDisable(true);
		btnCancelar.setDisable(false);
		
	}
	
	@FXML
	private void guardar(ActionEvent event){
		
		try {
			if(txtNombre.getText().trim().equals("") && txtPaterno.getText().trim().equals("") && txtMaterno.getText().trim().equals("") && txtCurp.getText().trim().equals("") && txtSexo.getText().trim().equals("") && txtFecha.getText().trim().equals("") && txtAfiliacion.getText().trim().equals("")  && txtEstado.getText().trim().equals("") && txtMunicipio.getText().trim().equals("")  && txtLocalidad.getText().trim().equals("")  && txtIndigena.getText().trim().equals("")  && txtOportunidades.getText().trim().equals("")) {
				JOptionPane.showMessageDialog(null, "Falta llenar campos");
			}else {
				if(txtId.getText().equals("null")) {
					nuevoUsuario.agregar(new Paciente(null,txtNombre.getText(),txtPaterno.getText(),txtMaterno.getText(),txtCurp.getText(),txtSexo.getText(),txtFecha.getText(),txtAfiliacion.getText(),txtEstado.getText(),txtMunicipio.getText(),txtLocalidad.getText(),txtIndigena.getText(),txtOportunidades.getText(),true));
					if(nuevoUsuario.guardar()) {
						JOptionPane.showMessageDialog(null, "Registro guardado");
						txtNombre.setText("");
						txtPaterno.setText("");
						txtMaterno.setText("");
						txtCurp.setText("");
						txtSexo.setText("");
						txtFecha.setText("");
						txtAfiliacion.setText("");
						txtEstado.setText("");
						txtMunicipio.setText("");
						txtLocalidad.setText("");
						txtIndigena.setText("");
						txtOportunidades.setText("");
						txtNombre.setDisable(true);
						txtPaterno.setDisable(true);
						txtMaterno.setDisable(true);
						txtCurp.setDisable(true);
						txtSexo.setDisable(true);
						txtFecha.setDisable(true);
						txtAfiliacion.setDisable(true);
						txtEstado.setDisable(true);
						txtMunicipio.setDisable(true);
						txtLocalidad.setDisable(true);
						txtIndigena.setDisable(true);
						txtOportunidades.setDisable(true);
						btnGuardar.setDisable(true);
						btnNuevo.setDisable(false);
						Llenar();
					}else {
						JOptionPane.showMessageDialog(null, "Ya existe el registro: "+txtNombre.getText()+"\n revisa en la papeleria de usuarios");
					}
				}else {
					nuevoUsuario.actualizar(new Paciente(txtId.getText(),txtNombre.getText(),txtPaterno.getText(),txtMaterno.getText(),txtCurp.getText(),txtSexo.getText(),txtFecha.getText(),txtAfiliacion.getText(), txtEstado.getText(), txtMunicipio.getText(), txtLocalidad.getText(), txtIndigena.getText(), txtOportunidades.getText(),true));
					txtId.setText("null");
					JOptionPane.showMessageDialog(null, "Registro actualizado con �xito");
					txtNombre.setText("");
					txtPaterno.setText("");
					txtMaterno.setText("");
					txtCurp.setText("");
					txtSexo.setText("");
					txtFecha.setText("");
					txtAfiliacion.setText("");
					txtEstado.setText("");
					txtMunicipio.setText("");
					txtLocalidad.setText("");
					txtMunicipio.setText("");
					txtIndigena.setText("");
					txtOportunidades.setText("");
					txtNombre.setDisable(true);
					txtPaterno.setDisable(true);
					txtMaterno.setDisable(true);
					txtCurp.setDisable(true);
					txtFecha.setDisable(true);
					txtEstado.setDisable(true);
					txtMunicipio.setDisable(true);
					txtLocalidad.setDisable(true);
					txtIndigena.setDisable(true);
					btnGuardar.setDisable(true);
					btnNuevo.setDisable(false);
					
					Llenar();
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@FXML
	private void editar(ActionEvent event){
		txtNombre.setDisable(false);
		txtPaterno.setDisable(false);
		txtMaterno.setDisable(false);
		txtCurp.setDisable(false);
		txtFecha.setDisable(false);
		txtSexo.setDisable(false);
		txtAfiliacion.setDisable(false);
		txtEstado.setDisable(false);
		txtMunicipio.setDisable(false);
		txtLocalidad.setDisable(false);
		txtIndigena.setDisable(false);
		txtOportunidades.setDisable(false);
		btnEditar.setDisable(true);
		btnGuardar.setDisable(false);
		
	}
	
	@FXML
	private void eliminar(ActionEvent event) {
		datoUsuario = (Paciente) tvPacientes.getSelectionModel().getSelectedItem();
		if(tvPacientes.getSelectionModel().isEmpty()) {
			
		}else {
			try {
				nuevoUsuario.eliminar(Integer.parseInt(datoUsuario.getId()));
				Llenar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
	
	@FXML
	private void seleccionar(){
		btnEditar.setDisable(false);
		btnNuevo.setDisable(true);
		btnEliminar.setDisable(false);
		datoUsuario = (Paciente) tvPacientes.getSelectionModel().getSelectedItem();
		if(tvPacientes.getSelectionModel().isEmpty()) {
			
		}else {
			txtId.setText((datoUsuario.getId()));
			txtNombre.setText(datoUsuario.getNombre());
			txtPaterno.setText(datoUsuario.getPaterno());
			txtMaterno.setText(datoUsuario.getMaterno());
			txtCurp.setText(datoUsuario.getCurp());
			txtSexo.setText(datoUsuario.getSexo());
			txtFecha.setText(datoUsuario.getFechaNacimiento());
			txtAfiliacion.setText(datoUsuario.getNoAfiliacion());
			txtEstado.setText(datoUsuario.getEstado());
			txtMunicipio.setText(datoUsuario.getMunicipio());
			txtLocalidad.setText(datoUsuario.getLocalidad());
			txtIndigena.setText(datoUsuario.getIndigena());
			txtOportunidades.setText(datoUsuario.getOportunidades());
		}
	}
	
	@FXML
	private void cancelar(){
	mainApp.cargarVentana(Main.pacientes);
    }
	
	@FXML
	private void irBorrados(){
		mainApp.cargarVentana(Main.pacientesb);
	}


	@Override
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
		
	}

}
