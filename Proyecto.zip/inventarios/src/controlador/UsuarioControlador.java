package controlador;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import comun.entidades.Usuario;
import comun.interfaces.ScreenControlable;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import logica.clUsuario;
import vista.Main;

	public class UsuarioControlador implements ScreenControlable {
	private Usuario datoUsuario;
	private Main mainApp;

	clUsuario nuevoUsuario = new clUsuario();
	List<Usuario> Usuarios= new ArrayList<Usuario>();
	
	@FXML
	Button btnNuevo, btnGuardar, btnEditar, btnEliminar, btnCancelar, btnRestaurar;
	
	@FXML
	TextField txtId, txtNombre, txtPaterno, txtMaterno, txtCurp, txtClues, txtCedula, txtUsuario, txtContra;
	
	@FXML
	TableView<Usuario> tvUsuarios;
	
	@FXML
	TableColumn tcId, tcNombre, tcPaterno, tcMaterno, tcCurp, tcClues, tcCedula, tcUsuario, tcContra; 
	
	
	public void initialize() {
		txtNombre.setDisable(true);
		txtPaterno.setDisable(true);
		txtMaterno.setDisable(true);
		txtCurp.setDisable(true);
		txtClues.setDisable(true);
		txtCedula.setDisable(true);
		txtUsuario.setDisable(true);
		txtContra.setDisable(true);
		btnGuardar.setDisable(true);
		btnEliminar.setDisable(true);
		btnEditar.setDisable(true);
		try {
				Llenar();
			}catch (Exception e) {
				e.printStackTrace();
		}
	}
	
	@FXML
	public void Llenar() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
		Usuarios=nuevoUsuario.listar();
		ObservableList<Usuario> data=FXCollections.observableArrayList(Usuarios);
		tcId.setCellValueFactory(new PropertyValueFactory<Usuario,String>("id"));
		tcNombre.setCellValueFactory(new PropertyValueFactory<Usuario,String>("nombre"));
		tcPaterno.setCellValueFactory(new PropertyValueFactory<Usuario,String>("paterno"));
		tcMaterno.setCellValueFactory(new PropertyValueFactory<Usuario,String>("materno"));
		tcCurp.setCellValueFactory(new PropertyValueFactory<Usuario,String>("curp"));
		tcClues.setCellValueFactory(new PropertyValueFactory<Usuario,String>("clues"));
		tcCedula.setCellValueFactory(new PropertyValueFactory<Usuario,String>("cedula"));
		tcUsuario.setCellValueFactory(new PropertyValueFactory<Usuario,String>("usuario"));
		tcContra.setCellValueFactory(new PropertyValueFactory<Usuario,String>("contra"));
		tvUsuarios.setItems(data);
	}
	
	@FXML
	private void nuevo(ActionEvent event){
		txtNombre.setDisable(false);
		txtPaterno.setDisable(false);
		txtMaterno.setDisable(false);
		txtCurp.setDisable(false);
		txtClues.setDisable(false);
		txtCedula.setDisable(false);
		txtUsuario.setDisable(false);
		txtContra.setDisable(false);
		btnNuevo.setDisable(true);
		btnGuardar.setDisable(false);
		btnEditar.setDisable(true);
		btnEliminar.setDisable(true);
		btnCancelar.setDisable(false);
		
	}
	
	@FXML
	private void guardar(ActionEvent event){
		
		try {
			if(txtUsuario.getText().trim().equals("") && txtContra.getText().trim().equals("") && txtNombre.getText().trim().equals("") && txtPaterno.getText().trim().equals("") && txtMaterno.getText().trim().equals("") && txtCurp.getText().trim().equals("") && txtClues.getText().trim().equals("") && txtCedula.getText().trim().equals("")) {
				JOptionPane.showMessageDialog(null, "se requieren llenar los dos campos");
			}else {
				if(txtId.getText().equals("null")) {
					nuevoUsuario.agregar(new Usuario(null,txtNombre.getText(),txtPaterno.getText(),txtMaterno.getText(),txtCurp.getText(),txtClues.getText(),txtCedula.getText(),txtUsuario.getText(), txtContra.getText(),true));
					if(nuevoUsuario.guardar()) {
						JOptionPane.showMessageDialog(null, "Registro exitoso");
						txtNombre.setText("");
						txtPaterno.setText("");
						txtMaterno.setText("");
						txtCurp.setText("");
						txtClues.setText("");
						txtCedula.setText("");
						txtUsuario.setText("");
						txtContra.setText("");
						txtUsuario.setDisable(true);
						txtContra.setDisable(true);
						btnGuardar.setDisable(true);
						btnNuevo.setDisable(false);
						Llenar();
					}else {
						JOptionPane.showMessageDialog(null, "Ya existe un registro con este nombre: "+txtUsuario.getText()+"\n revisa en la papeleria de usuarios");
					}
				}else {
					nuevoUsuario.actualizar(new Usuario(txtId.getText(),txtNombre.getText(),txtPaterno.getText(),txtMaterno.getText(),txtCurp.getText(),txtClues.getText(),txtCedula.getText(),txtUsuario.getText(), txtContra.getText(),true));
					txtId.setText("null");
					JOptionPane.showMessageDialog(null, "Registro actualizado con �xito");
					txtNombre.setText("");
					txtPaterno.setText("");
					txtMaterno.setText("");
					txtCurp.setText("");
					txtClues.setText("");
					txtCedula.setText("");
					txtUsuario.setText("");
					txtContra.setText("");
					txtNombre.setDisable(true);
					txtPaterno.setDisable(true);
					txtMaterno.setDisable(true);
					txtCurp.setDisable(true);
					txtClues.setDisable(true);
					txtCedula.setDisable(true);
					txtUsuario.setDisable(true);
					txtContra.setDisable(true);
					btnGuardar.setDisable(true);
					btnNuevo.setDisable(false);
					
					Llenar();
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@FXML
	private void editar(ActionEvent event){
		txtNombre.setDisable(false);
		txtPaterno.setDisable(false);
		txtMaterno.setDisable(false);
		txtCurp.setDisable(false);
		txtClues.setDisable(false);
		txtCedula.setDisable(false);
		txtUsuario.setDisable(false);
		txtContra.setDisable(false);
		btnEditar.setDisable(true);
		btnGuardar.setDisable(false);
		
	}
	
	@FXML
	private void eliminar(ActionEvent event) {
		datoUsuario = (Usuario) tvUsuarios.getSelectionModel().getSelectedItem();
		if(tvUsuarios.getSelectionModel().isEmpty()) {
			
		}else {
			try {
				nuevoUsuario.eliminar(Integer.parseInt(datoUsuario.getId()));
				Llenar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
	
	@FXML
	private void seleccionar(){
		btnEditar.setDisable(false);
		btnNuevo.setDisable(true);
		btnEliminar.setDisable(false);
		datoUsuario = (Usuario) tvUsuarios.getSelectionModel().getSelectedItem();
		if(tvUsuarios.getSelectionModel().isEmpty()) {
			
		}else {
			txtId.setText((datoUsuario.getId()));
			txtNombre.setText(datoUsuario.getNombre());
			txtPaterno.setText(datoUsuario.getPaterno());
			txtMaterno.setText(datoUsuario.getMaterno());
			txtCurp.setText(datoUsuario.getCurp());
			txtClues.setText(datoUsuario.getClues());
			txtCedula.setText(datoUsuario.getCedula());
			txtUsuario.setText(datoUsuario.getUsuario());
			txtContra.setText(datoUsuario.getContra());
		}
	}
	
	@FXML
	private void cancelar(){
	mainApp.cargarVentana(Main.doctores);
    }
	
	@FXML
	private void irBorrados(){
		mainApp.cargarVentana(Main.usuariosb);
	}


	@Override
	public void setMainApp(Main mainApp) {
		this.mainApp = mainApp;
		
	}

}
