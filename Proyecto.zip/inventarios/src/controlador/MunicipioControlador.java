package controlador;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Municipio;
import comun.interfaces.ScreenControlable;
import datos.cdMunicipio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import vista.Main;

public class MunicipioControlador implements ScreenControlable{
	private Main mainApp;
	private cdMunicipio nuevoPrograma= new cdMunicipio();
	private List<Municipio> misprogramasa=new ArrayList<Municipio>();
	Municipio datosPrograma;
	
	@FXML
	TextField txtNombre;
	@FXML
	TextField txtId;
	@FXML
	Button btnGuardar;
	@FXML
	Button btnEliminar;
	@FXML
	Button btnActualizar;
	@FXML
	TableView<Municipio> tvprogramas;
	@FXML
	TableColumn tcid;
	@FXML
	TableColumn tcnombre;
	
	@Override
	public void setMainApp(Main mainApp) {
		this.mainApp=mainApp;
	}
	
	@FXML
	public void initialize() {
		try {
			Llenar();
			btnActualizar.setDisable(true);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void Llenar() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{ 
		misprogramasa=nuevoPrograma.listar();
		ObservableList<Municipio> data = FXCollections.observableArrayList(misprogramasa);
		 tcid.setCellValueFactory(new PropertyValueFactory<Municipio,String>("id")); 
		 tcnombre.setCellValueFactory(new PropertyValueFactory<Municipio,String>("nombre")); 
		 tvprogramas.setItems(data);
	}
	@FXML
	private void eliminar(ActionEvent event) {
		try {
			nuevoPrograma.eliminar(Integer.parseInt(txtId.getText()));
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FXML
	private void actualizar(ActionEvent event) {
		System.out.println(txtId.getText());
		System.out.println(txtNombre.getText());
		
		try {
			nuevoPrograma.actualizar(new Municipio(txtId.getText(), txtNombre.getText()));
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	@FXML
	private void guardar(ActionEvent event) {
		try {
			System.out.println(txtId.getText());
			if(txtId.getText().equals("null")) {
				nuevoPrograma.agregar(new Municipio(null, txtNombre.getText()));
				txtNombre.setText("");
			}else {
				nuevoPrograma.actualizar(new Municipio(txtId.getText(), txtNombre.getText()));
				txtId.setText("null");
				txtNombre.setText("");
			}
			
			Llenar();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	@FXML
	private void seleccionar() {
		datosPrograma = (Municipio) tvprogramas.getSelectionModel().getSelectedItem();
		txtNombre.setText(datosPrograma.getNombre());
		txtId.setText(datosPrograma.getId());
	}
	

}
