package controlador;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Usuario;
import comun.interfaces.ScreenControlable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import logica.clUsuario;
import vista.Main;

public class UsuarioEControlador implements ScreenControlable {
	private Usuario datoUsuario;
	private Main mainApp;
	clUsuario nuevoUsuarioB = new clUsuario();
	List<Usuario> UsuariosB= new ArrayList<Usuario>();
	
	@FXML
	Button btnRestaurar;
	
	@FXML
	TableView<Usuario> tvUsuariosB;
	
	@FXML
	TableColumn tcId, tcNombre, tcPaterno, tcMaterno, tcCurp, tcClues, tcCedula, tcUsuario, tcContra; 
	
	@FXML
	TextField txtId, txtNombre, txtPaterno, txtMaterno, txtCurp, txtClues, txtCedula, txtUsuario, txtContra;
	
	public void initialize() {
		txtNombre.setDisable(true);
		txtPaterno.setDisable(true);
		txtMaterno.setDisable(true);
		txtCurp.setDisable(true);
		txtClues.setDisable(true);
		txtCedula.setDisable(true);
		txtUsuario.setDisable(true);
		txtContra.setDisable(true);
		txtId.setDisable(true);
		try {
				LlenarB();
			}catch (Exception e) {
				e.printStackTrace();
		}
	}
	
	@FXML
	public void LlenarB() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
		System.out.println("Recuperar");
		UsuariosB=nuevoUsuarioB.listarB();
		ObservableList<Usuario> data=FXCollections.observableArrayList(UsuariosB);
		tcId.setCellValueFactory(new PropertyValueFactory<Usuario,String>("id"));
		tcNombre.setCellValueFactory(new PropertyValueFactory<Usuario,String>("nombre"));
		tcPaterno.setCellValueFactory(new PropertyValueFactory<Usuario,String>("paterno"));
		tcMaterno.setCellValueFactory(new PropertyValueFactory<Usuario,String>("materno"));
		tcCurp.setCellValueFactory(new PropertyValueFactory<Usuario,String>("curp"));
		tcClues.setCellValueFactory(new PropertyValueFactory<Usuario,String>("clues"));
		tcCedula.setCellValueFactory(new PropertyValueFactory<Usuario,String>("cedula"));
		tcUsuario.setCellValueFactory(new PropertyValueFactory<Usuario,String>("usuario"));
		tcContra.setCellValueFactory(new PropertyValueFactory<Usuario,String>("contra"));
		tvUsuariosB.setItems(data);
	}
	
	@FXML
	private void seleccionar(){
		datoUsuario = (Usuario) tvUsuariosB.getSelectionModel().getSelectedItem();
		if(tvUsuariosB.getSelectionModel().isEmpty()) {
			
		}else {
			txtId.setText((datoUsuario.getId()));
			txtNombre.setText(datoUsuario.getNombre());
			txtPaterno.setText(datoUsuario.getPaterno());
			txtMaterno.setText(datoUsuario.getMaterno());
			txtCurp.setText(datoUsuario.getCurp());
			txtClues.setText(datoUsuario.getClues());
			txtCedula.setText(datoUsuario.getCedula());
			txtUsuario.setText(datoUsuario.getUsuario());
			txtContra.setText(datoUsuario.getContra());
		}
	}
	
	@FXML
	private void restaurar(ActionEvent event) {
		datoUsuario = (Usuario) tvUsuariosB.getSelectionModel().getSelectedItem();
		if(tvUsuariosB.getSelectionModel().isEmpty()) {
			
		}else {
			try {
				nuevoUsuarioB.restaurar(Integer.parseInt(datoUsuario.getId()));
				LlenarB();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	

	@Override
	public void setMainApp(Main mainApp) {
		// TODO Auto-generated method stub
		this.mainApp = mainApp;
		
	}

}
