package logica;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import configuracion.parametrosConexion;

public class conexion {
	public Connection conexion=null;
	public Statement un_st=null;
	public DatabaseMetaData dbmd;
	public String un_sql;
	public ResultSet resultado=null;
	//observa que este atributo es un objeto de la clase parametrosconexion
	parametrosConexion pc= new parametrosConexion();
	
	public conexion () throws ClassNotFoundException,SQLException
	{
		// invocamos el metodo asignar parametros de la clase parametrosconexion
		pc.asignarParametros();
		//se indica el manejador de base de datos al cual se va a conectar
		Class.forName("org.postgresql.Driver");
		// se realiza la conexi�n a la base de datos
		conexion=DriverManager.getConnection("jdbc:postgresql://"+pc.getIp()+":"+  
	    pc.getPuerto()+"/"+pc.getBasedatos()+"",""+pc.getUsuario()+"",""+pc.getContrasenia()+"");
		dbmd=conexion.getMetaData();
		un_st=conexion.createStatement();
	}
	public void desconectar(){
		try{
			conexion.close();
		}catch(Exception ex){
			ex.getMessage();
		}
	}


}
