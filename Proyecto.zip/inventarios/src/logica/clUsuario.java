package logica;

import java.sql.SQLException;
import java.util.List;

import comun.entidades.Usuario;
import comun.interfaces.IUsuario;
import datos.cdUsuario;

public class clUsuario implements IUsuario{
	
	private Usuario miUsuario;
	private cdUsuario almacenUsuario = new cdUsuario();

	@Override
	public boolean agregar(Usuario Usuario)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		miUsuario=Usuario;
		return false;
	}

	@Override
	public boolean actualizar(Usuario Usuario)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
			if(almacenUsuario.actualizar(Usuario)) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public void eliminar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		almacenUsuario.eliminar(id);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Usuario> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return almacenUsuario.listar();

	}

	@Override
	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		if(almacenUsuario.agregar(miUsuario)) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public List<Usuario> listarB()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return almacenUsuario.listarB();
	}

	@Override
	public void restaurar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		almacenUsuario.restaurar(id);
	}

	

}
