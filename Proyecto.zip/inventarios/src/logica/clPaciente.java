package logica;

import java.sql.SQLException;
import java.util.List;

import comun.entidades.Paciente;
import comun.interfaces.IPaciente;
import datos.cdPacientes;

public class clPaciente implements IPaciente{
	
	private Paciente miUsuario;
	private cdPacientes almacenUsuario = new cdPacientes();

	@Override
	public boolean agregar(Paciente Paciente)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		miUsuario=Paciente;
		return false;
	}

	@Override
	public boolean actualizar(Paciente Paciente)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
			if(almacenUsuario.actualizar(Paciente)) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public void eliminar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		almacenUsuario.eliminar(id);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Paciente> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return almacenUsuario.listar();

	}

	@Override
	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		if(almacenUsuario.agregar(miUsuario)) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public List<Paciente> listarB()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return almacenUsuario.listarB();
	}

	@Override
	public void restaurar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		almacenUsuario.restaurar(id);
	}

	

}
