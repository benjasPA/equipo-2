package datos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Atencion;
import logica.conexion;

public class cdAtencion {

	public boolean agregar(Atencion Atencion)	throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		
		conexion con=new conexion();
		con.un_sql="insert into atencion(nombre) values('"+Atencion.getNombre()+"')";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return true;
	}

	public boolean actualizar(Atencion Atencion)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con=new conexion();
		con.un_sql="update atencion set nombre='"+Atencion.getNombre()+"' where id='"+Atencion.getId()+"';";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return false;
	}

	public boolean eliminar(int idplaca)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
			conexion con=new conexion();
			con.un_sql="update atencion set estatus=false where id='"+idplaca+"';";
			System.out.println(con.un_sql);
			con.un_st.executeUpdate(con.un_sql);
			con.desconectar();
		return true;
	}

	public List<Atencion> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		List<Atencion> listaProgramas=new ArrayList<Atencion>(); 
		conexion con=new conexion();   
		con.un_sql="select * from atencion where estatus='true'";
		con.resultado=con.un_st.executeQuery(con.un_sql); 
		while(con.resultado.next())   { 
			Atencion programa = new Atencion();
			programa.setId(con.resultado.getString("id"));   
			programa.setNombre(con.resultado.getString("nombre")); 
			listaProgramas.add(programa);
		}
		con.desconectar(); 
		return listaProgramas;
	}

	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	

}
