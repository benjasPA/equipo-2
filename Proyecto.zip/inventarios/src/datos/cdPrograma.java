package datos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Programa;
import logica.conexion;

public class cdPrograma {

	public boolean agregar(Programa Programa)	throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		
		conexion con=new conexion();
		con.un_sql="insert into programas(nombre) values('"+Programa.getNombre()+"')";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return true;
	}

	public boolean actualizar(Programa Programa)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con=new conexion();
		con.un_sql="update programas set nombre='"+Programa.getNombre()+"' where id='"+Programa.getId()+"';";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return false;
	}

	public boolean eliminar(int idplaca)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
			conexion con=new conexion();
			con.un_sql="update programas set estatus=false where id='"+idplaca+"';";
			System.out.println(con.un_sql);
			con.un_st.executeUpdate(con.un_sql);
			con.desconectar();
		return true;
	}

	public List<Programa> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		List<Programa> listaProgramas=new ArrayList<Programa>(); 
		conexion con=new conexion();   
		con.un_sql="select * from programas where estatus='true'";
		con.resultado=con.un_st.executeQuery(con.un_sql); 
		while(con.resultado.next())   { 
			Programa programa = new Programa();
			programa.setId(con.resultado.getString("id"));   
			programa.setNombre(con.resultado.getString("nombre")); 
			listaProgramas.add(programa);
		}
		con.desconectar(); 
		return listaProgramas;
	}

	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	

}
