package datos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Metodos;
import logica.conexion;

public class cdMetodos {

	public boolean agregar(Metodos Metodos)	throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		
		conexion con=new conexion();
		con.un_sql="insert into metodos(nombre) values('"+Metodos.getNombre()+"')";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return true;
	}

	public boolean actualizar(Metodos Metodos)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con=new conexion();
		con.un_sql="update metodos set nombre='"+Metodos.getNombre()+"' where id='"+Metodos.getId()+"';";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return false;
	}

	public boolean eliminar(int idplaca)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
			conexion con=new conexion();
			con.un_sql="update metodos set estatus=false where id='"+idplaca+"';";
			System.out.println(con.un_sql);
			con.un_st.executeUpdate(con.un_sql);
			con.desconectar();
		return true;
	}

	public List<Metodos> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		List<Metodos> listaProgramas=new ArrayList<Metodos>(); 
		conexion con=new conexion();   
		con.un_sql="select * from metodos where estatus='true'";
		con.resultado=con.un_st.executeQuery(con.un_sql); 
		while(con.resultado.next())   { 
			Metodos programa = new Metodos();
			programa.setId(con.resultado.getString("id"));   
			programa.setNombre(con.resultado.getString("nombre")); 
			listaProgramas.add(programa);
		}
		con.desconectar(); 
		return listaProgramas;
	}

	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	

}
