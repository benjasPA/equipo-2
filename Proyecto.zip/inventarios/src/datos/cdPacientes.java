package datos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Paciente;
import comun.interfaces.IPaciente;
import logica.conexion;

public class cdPacientes implements IPaciente{

	@Override
	public boolean agregar(Paciente Paciente)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		int total=0;
		conexion con = new conexion();
		con.un_sql="select count(id) as id from pacientes where trim(lower(paciente))= trim(lower('"+Paciente.getNombre()+"'))";
		con.un_sql="select count(id) as id from pacientes where trim(lower(paciente))= trim(lower('"+Paciente.getPaterno()+"'))";
		con.resultado=con.un_st.executeQuery(con.un_sql);
		con.resultado.next();
	    total=con.resultado.getInt("id");
		if(total>0) {
			con.desconectar();
			return false;
		}else {
			con.un_sql="insert into pacientes(nombre,paterno,materno,curp,sexo,fechaNacimiento,noAfiliacion,estado,municipio,localidad,indigena,oportunidades, estatus) values('"+Paciente.getNombre()+"','"+Paciente.getPaterno()+"','"+Paciente.getMaterno()+"','"+Paciente.getCurp()+"','"+Paciente.getSexo()+"','"+Paciente.getFechaNacimiento()+"','"+Paciente.getNoAfiliacion()+"','"+Paciente.getEstado()+"','"+Paciente.getMunicipio()+"', '"+Paciente.getLocalidad()+"','"+Paciente.getIndigena()+"','"+Paciente.getOportunidades()+"','"+true+"')";
			con.un_st.execute(con.un_sql);
			con.desconectar();
			return true;
		}
	}
  //+Usuario.getContra()
	@Override
	public boolean actualizar(Paciente Paciente)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con=new conexion();
		con.un_sql="update pacientes set nombre='"+Paciente.getNombre()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set paterno='"+Paciente.getPaterno()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set materno='"+Paciente.getMaterno()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set curp='"+Paciente.getCurp()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set sexo='"+Paciente.getSexo()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set fechaNacimiento='"+Paciente.getFechaNacimiento()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set noAfiliacion='"+Paciente.getNoAfiliacion()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set estado='"+Paciente.getEstado()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set municipio='"+Paciente.getMunicipio()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set localidad='"+Paciente.getLocalidad()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set indigena='"+Paciente.getIndigena()+"' where id='"+Paciente.getId()+"'";
		con.un_sql="update pacientes set oportunidades='"+Paciente.getOportunidades()+"' where id='"+Paciente.getId()+"'";
		con.un_st.execute(con.un_sql);
		con.desconectar();
		return false;
	}

	@Override
	public void eliminar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con = new conexion();
		con.un_sql="update pacientes set estatus=false where id='"+id+"';";
		con.un_st.execute(con.un_sql);
		con.desconectar();	
	}
	
	

	@Override
	public List<Paciente> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		
		List<Paciente> listaUsuario=new ArrayList<Paciente>();
		conexion con=new conexion();
		con.un_sql="select id,nombre,paterno,materno,curp,sexo,fechaNacimiento,noAfiliacion,estado,municipio,localidad,indigena,oportunidades,estatus from pacientes where estatus=true "; 
		con.resultado=con.un_st.executeQuery(con.un_sql);
		while(con.resultado.next())
		{
		 
		Paciente usuario = new Paciente();
		usuario.setId(con.resultado.getString("id"));
		usuario.setNombre(con.resultado.getString("nombre"));
		usuario.setPaterno(con.resultado.getString("paterno"));
		usuario.setMaterno(con.resultado.getString("materno"));
		usuario.setCurp(con.resultado.getString("curp"));
		usuario.setSexo(con.resultado.getString("sexo"));
		usuario.setFechaNacimiento(con.resultado.getString("fechaNacimiento"));
		usuario.setNoAfiliacion(con.resultado.getString("noAfiliacion"));
		usuario.setEstado(con.resultado.getString("estado"));
		usuario.setMunicipio(con.resultado.getString("municipio"));
		usuario.setLocalidad(con.resultado.getString("localidad"));
		usuario.setIndigena(con.resultado.getString("indigena"));
		usuario.setOportunidades(con.resultado.getString("oportunidades"));
		listaUsuario.add(usuario);
		  
		}
		con.desconectar();
		return listaUsuario;
	}

	@Override
	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public List<Paciente> listarB()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		List<Paciente> listaUsuarioB=new ArrayList<Paciente>();
		conexion con=new conexion();
		con.un_sql="select id,nombre,paterno,materno,curp,sexo,fechaNacimiento,noAfiliacion,estado,municipio,localidad,indigena,oportunidades,estatus from usuarios where estatus=false "; //puedo afrefar order by
		con.resultado=con.un_st.executeQuery(con.un_sql);
		while(con.resultado.next())
		{
		 
	    Paciente usuario = new Paciente();
		usuario.setId(con.resultado.getString("id"));
		usuario.setNombre(con.resultado.getString("nombre"));
		usuario.setPaterno(con.resultado.getString("paterno"));
		usuario.setMaterno(con.resultado.getString("materno"));
		usuario.setCurp(con.resultado.getString("curp"));
		usuario.setSexo(con.resultado.getString("sexo"));
		usuario.setFechaNacimiento(con.resultado.getString("fechaNacimiento"));
		usuario.setNoAfiliacion(con.resultado.getString("noAfiliacion"));
		usuario.setEstado(con.resultado.getString("estado"));
		usuario.setMunicipio(con.resultado.getString("municipio"));
		usuario.setLocalidad(con.resultado.getString("localidad"));
		usuario.setIndigena(con.resultado.getString("indigena"));
		usuario.setOportunidades(con.resultado.getString("oportunidades"));
		listaUsuarioB.add(usuario);
		  
		}
		con.desconectar();
		return listaUsuarioB;
	}
	@Override
	public void restaurar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con = new conexion();
		con.un_sql="update pacientes set estatus=true where id='"+id+"';";
		con.un_st.execute(con.un_sql);
		con.desconectar();
		
		
	}
	
	

}
