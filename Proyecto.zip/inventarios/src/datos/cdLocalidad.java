package datos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Localidad;
import logica.conexion;

public class cdLocalidad {

	public boolean agregar(Localidad Localidad)	throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		
		conexion con=new conexion();
		con.un_sql="insert into localidad(nombre) values('"+Localidad.getNombre()+"')";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return true;
	}

	public boolean actualizar(Localidad Localidad)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con=new conexion();
		con.un_sql="update localidad set nombre='"+Localidad.getNombre()+"' where id='"+Localidad.getId()+"';";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return false;
	}

	public boolean eliminar(int idplaca)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
			conexion con=new conexion();
			con.un_sql="update localidad set estatus=false where id='"+idplaca+"';";
			System.out.println(con.un_sql);
			con.un_st.executeUpdate(con.un_sql);
			con.desconectar();
		return true;
	}

	public List<Localidad> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		List<Localidad> listaProgramas=new ArrayList<Localidad>(); 
		conexion con=new conexion();   
		con.un_sql="select * from localidad where estatus='true'";
		con.resultado=con.un_st.executeQuery(con.un_sql); 
		while(con.resultado.next())   { 
			Localidad programa = new Localidad();
			programa.setId(con.resultado.getString("id"));   
			programa.setNombre(con.resultado.getString("nombre")); 
			listaProgramas.add(programa);
		}
		con.desconectar(); 
		return listaProgramas;
	}

	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	

}
