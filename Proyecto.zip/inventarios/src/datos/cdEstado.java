package datos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Estado;
import logica.conexion;

public class cdEstado {

	public boolean agregar(Estado Estado)	throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		
		conexion con=new conexion();
		con.un_sql="insert into estado(nombre) values('"+Estado.getNombre()+"')";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return true;
	}

	public boolean actualizar(Estado Estado)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con=new conexion();
		con.un_sql="update estado set nombre='"+Estado.getNombre()+"' where id='"+Estado.getId()+"';";
		System.out.println(con.un_sql);
		con.un_st.executeUpdate(con.un_sql);
		con.desconectar();
		return false;
	}

	public boolean eliminar(int idplaca)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
			conexion con=new conexion();
			con.un_sql="update estado set estatus=false where id='"+idplaca+"';";
			System.out.println(con.un_sql);
			con.un_st.executeUpdate(con.un_sql);
			con.desconectar();
		return true;
	}

	public List<Estado> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		List<Estado> listaProgramas=new ArrayList<Estado>(); 
		conexion con=new conexion();   
		con.un_sql="select * from estado where estatus='true'";
		con.resultado=con.un_st.executeQuery(con.un_sql); 
		while(con.resultado.next())   { 
			Estado programa = new Estado();
			programa.setId(con.resultado.getString("id"));   
			programa.setNombre(con.resultado.getString("nombre")); 
			listaProgramas.add(programa);
		}
		con.desconectar(); 
		return listaProgramas;
	}

	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	

}
