package datos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import comun.entidades.Usuario;
import comun.interfaces.IUsuario;
import logica.conexion;

public class cdUsuario implements IUsuario{

	@Override
	public boolean agregar(Usuario Usuario)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		int total=0;
		conexion con = new conexion();
		con.un_sql="select count(id) as id from usuarios where trim(lower(usuario))= trim(lower('"+Usuario.getUsuario()+"'))";
		con.resultado=con.un_st.executeQuery(con.un_sql);
		con.resultado.next();
	    total=con.resultado.getInt("id");
		if(total>0) {
			con.desconectar();
			return false;
		}else {
			con.un_sql="insert into usuarios(nombre,paterno,materno,curp,clues,cedula,usuario,contra,estatus) values('"+Usuario.getNombre()+"','"+Usuario.getPaterno()+"','"+Usuario.getMaterno()+"','"+Usuario.getCurp()+"','"+Usuario.getClues()+"','"+Usuario.getCedula()+"','"+Usuario.getUsuario()+"','"+Usuario.getContra()+"','"+true+"')";
			con.un_st.execute(con.un_sql);
			con.desconectar();
			return true;
		}
	}
  //+Usuario.getContra()
	@Override
	public boolean actualizar(Usuario Usuario)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con=new conexion();
		con.un_sql="update usuarios set nombre='"+Usuario.getNombre()+"' where id='"+Usuario.getId()+"'";
		con.un_sql="update usuarios set paterno='"+Usuario.getPaterno()+"' where id='"+Usuario.getId()+"'";
		con.un_sql="update usuarios set materno='"+Usuario.getMaterno()+"' where id='"+Usuario.getId()+"'";
		con.un_sql="update usuarios set curp='"+Usuario.getCurp()+"' where id='"+Usuario.getId()+"'";
		con.un_sql="update usuarios set clues='"+Usuario.getClues()+"' where id='"+Usuario.getId()+"'";
		con.un_sql="update usuarios set cedula='"+Usuario.getCedula()+"' where id='"+Usuario.getId()+"'";
		con.un_sql="update usuarios set usuario='"+Usuario.getUsuario()+"' where id='"+Usuario.getId()+"'";
		con.un_sql="update usuarios set contra='"+Usuario.getContra()+"' where id='"+Usuario.getId()+"'";
		con.un_st.execute(con.un_sql);
		con.desconectar();
		return false;
	}

	@Override
	public void eliminar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con = new conexion();
		con.un_sql="update usuarios set estatus=false where id='"+id+"';";
		con.un_st.execute(con.un_sql);
		con.desconectar();	
	}
	
	

	@Override
	public List<Usuario> listar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		
		List<Usuario> listaUsuario=new ArrayList<Usuario>();
		conexion con=new conexion();
		con.un_sql="select id,nombre,paterno,materno,curp,clues,cedula,usuario,contra,estatus from usuarios where estatus=true "; 
		con.resultado=con.un_st.executeQuery(con.un_sql);
		while(con.resultado.next())
		{
		 
		Usuario usuario = new Usuario();
		usuario.setId(con.resultado.getString("id"));
		usuario.setNombre(con.resultado.getString("nombre"));
		usuario.setPaterno(con.resultado.getString("paterno"));
		usuario.setMaterno(con.resultado.getString("materno"));
		usuario.setCurp(con.resultado.getString("curp"));
		usuario.setClues(con.resultado.getString("clues"));
		usuario.setCedula(con.resultado.getString("cedula"));
		usuario.setUsuario(con.resultado.getString("usuario"));
		usuario.setContra(con.resultado.getString("contra"));
		listaUsuario.add(usuario);
		  
		}
		con.desconectar();
		return listaUsuario;
	}

	@Override
	public boolean guardar()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public List<Usuario> listarB()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		List<Usuario> listaUsuarioB=new ArrayList<Usuario>();
		conexion con=new conexion();
		con.un_sql="select id,nombre,paterno,materno,curp,clues,cedula,usuario,contra,estatus from usuarios where estatus=false "; //puedo afrefar order by
		con.resultado=con.un_st.executeQuery(con.un_sql);
		while(con.resultado.next())
		{
		 
		Usuario usuario = new Usuario();
		usuario.setId(con.resultado.getString("id"));
		usuario.setNombre(con.resultado.getString("nombre"));
		usuario.setPaterno(con.resultado.getString("paterno"));
		usuario.setMaterno(con.resultado.getString("materno"));
		usuario.setCurp(con.resultado.getString("curp"));
		usuario.setClues(con.resultado.getString("clues"));
		usuario.setCedula(con.resultado.getString("cedula"));
		usuario.setUsuario(con.resultado.getString("usuario"));
		usuario.setContra(con.resultado.getString("contra"));
		listaUsuarioB.add(usuario);
		  
		}
		con.desconectar();
		return listaUsuarioB;
	}
	@Override
	public void restaurar(int id)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		// TODO Auto-generated method stub
		conexion con = new conexion();
		con.un_sql="update usuarios set estatus=true where id='"+id+"';";
		con.un_st.execute(con.un_sql);
		con.desconectar();
		
		
	}
	
	

}
