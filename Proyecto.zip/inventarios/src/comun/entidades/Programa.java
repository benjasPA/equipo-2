package comun.entidades;

public class Programa {
	private String id,nombre;
	public Programa() {}
	public Programa(String id,String nombre) {
		this.setId(id);
		this.setNombre(nombre);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}
