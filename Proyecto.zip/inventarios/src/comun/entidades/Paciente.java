package comun.entidades;

public class Paciente {
	
	private String id, nombre, paterno, materno, curp, sexo, fechaNacimiento, noAfiliacion, estado, municipio, localidad, indigena, oportunidades;
	private boolean estatus;
	
	public Paciente() {}
	public Paciente(String id,String nombre, String paterno, String materno, String curp, String sexo, String fechaNacimiento, String noAfiliacion, String estado, String municipio, String localidad, String indigena, String oportunidades, boolean estatus) {
		this.setId(id);
		this.setNombre(nombre);
		this.setPaterno(paterno);
		this.setMaterno(materno);
		this.setCurp(curp);
		this.setSexo(sexo);
		this.setFechaNacimiento(fechaNacimiento);
		this.setNoAfiliacion(noAfiliacion);
		this.setEstado(estado);
		this.setMunicipio(municipio);
		this.setLocalidad(localidad);
		this.setIndigena(indigena);
		this.setOportunidades(oportunidades);
		this.setEstatus(estatus);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getPaterno() {
		return paterno;
	}
	public void setPaterno(String paterno) {
		this.paterno = paterno;
	}
	public String getMaterno() {
		return materno;
	}
	public void setMaterno(String materno) {
		this.materno = materno;
	}
	public String getCurp() {
		return curp;
	}
	public void setCurp(String curp) {
		this.curp = curp;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public String getNoAfiliacion() {
		return noAfiliacion;
	}
	public void setNoAfiliacion(String noAfiliacion) {
		this.noAfiliacion = noAfiliacion;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getMunicipio() {
		return municipio;
	}
	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}
	public String getLocalidad() {
		return localidad;
	}
	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}
	public String getIndigena() {
		return indigena;
	}
	public void setIndigena(String indigena) {
		this.indigena = indigena;
	}
	public String getOportunidades() {
		return oportunidades;
	}
	public void setOportunidades(String oportunidades) {
		this.oportunidades = oportunidades;
	}
	public boolean isEstatus() {
		return estatus;
	}
	public void setEstatus(boolean estatus) {
		this.estatus = estatus;
	}

}
