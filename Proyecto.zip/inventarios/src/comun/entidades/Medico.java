package comun.entidades;

public class Medico {
	
	private String id, usuario, paterno, materno, nombre, curp, clues, cedula, contrasenia;
	
	public Medico(){}
	public Medico(String id,String usuario, String paterno,String materno,String nombre,String curp,String clues,String cedula, String contrasenia, boolean estatus){
		this.setId(id);
		this.setUsuario(usuario);
		this.setPaterno(paterno);
		this.setMaterno(materno);
		this.setNombre(nombre);
		this.setCurp(curp);
		this.setClues(clues);
		this.setCedula(cedula);
		this.setContrasenia(contrasenia);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPaterno() {
		return paterno;
	}
	public void setPaterno(String paterno) {
		this.paterno = paterno;
	}
	public String getMaterno() {
		return materno;
	}
	public void setMaterno(String materno) {
		this.materno = materno;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCurp() {
		return curp;
	}
	public void setCurp(String curp) {
		this.curp = curp;
	}
	public String getClues() {
		return clues;
	}
	public void setClues(String clues) {
		this.clues = clues;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getContrasenia() {
		return contrasenia;
	}
	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	
}
