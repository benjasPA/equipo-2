package comun.entidades;

public class Consulta {
	int id;
	private boolean estatus;
	private String noAfiliacion, fecha, hora, visita, programa, controlPrenatal, estadoNutricional, nivel, tratamiento, hidratacion, metodo, atencion, deteccion, otro, diagnostico;
	public Consulta() {}
	public Consulta(int id,String noAfiliacion,String fecha,String hora,String visita,String programa,String controlPrenatal,String estadoNutricional,String nivel,String tratamiento,String hidratacion,String metodo,String atencion,String deteccion,String otro,String diagnostico, boolean estatus) {
		this.id=id;
		this.setNoAfiliacion(noAfiliacion);
		this.setFecha(fecha);
		this.setHora(hora);
		this.setVisita(visita);
		this.setPrograma(programa);
		this.setControlPrenatal(controlPrenatal);
		this.setEstadoNutricional(estadoNutricional);
		this.setNivel(nivel);
		this.setTratamiento(tratamiento);
		this.setHidratacion(hidratacion);
		this.setMetodo(metodo);
		this.setAtencion(atencion);
		this.setDeteccion(deteccion);
		this.setOtro(otro);
		this.setDiagnostico(diagnostico);
		this.setEstatus(estatus);
		
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNoAfiliacion() {
		return noAfiliacion;
	}
	public void setNoAfiliacion(String noAfiliacion) {
		this.noAfiliacion = noAfiliacion;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	public String getVisita() {
		return visita;
	}
	public void setVisita(String visita) {
		this.visita = visita;
	}
	public String getPrograma() {
		return programa;
	}
	public void setPrograma(String programa) {
		this.programa = programa;
	}
	public String getControlPrenatal() {
		return controlPrenatal;
	}
	public void setControlPrenatal(String controlPrenatal) {
		this.controlPrenatal = controlPrenatal;
	}
	public String getEstadoNutricional() {
		return estadoNutricional;
	}
	public void setEstadoNutricional(String estadoNutricional) {
		this.estadoNutricional = estadoNutricional;
	}
	public String getNivel() {
		return nivel;
	}
	public void setNivel(String nivel) {
		this.nivel = nivel;
	}
	public String getTratamiento() {
		return tratamiento;
	}
	public void setTratamiento(String tratamiento) {
		this.tratamiento = tratamiento;
	}
	public String getHidratacion() {
		return hidratacion;
	}
	public void setHidratacion(String hidratacion) {
		this.hidratacion = hidratacion;
	}
	public String getMetodo() {
		return metodo;
	}
	public void setMetodo(String metodo) {
		this.metodo = metodo;
	}
	public String getAtencion() {
		return atencion;
	}
	public void setAtencion(String atencion) {
		this.atencion = atencion;
	}
	public String getDeteccion() {
		return deteccion;
	}
	public void setDeteccion(String deteccion) {
		this.deteccion = deteccion;
	}
	public String getOtro() {
		return otro;
	}
	public void setOtro(String otro) {
		this.otro = otro;
	}
	public String getDiagnostico() {
		return diagnostico;
	}
	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}
	public boolean isEstatus() {
		return estatus;
	}
	public void setEstatus(boolean estatus) {
		this.estatus = estatus;
	}
	
	
}
