package comun.entidades;

public class Usuario {
	private String id;
	private String nombre,paterno,materno,curp,clues,cedula,usuario,contra;
    private boolean estatus;
	
	
	public Usuario() {}
	
    public Usuario(String id,String nombre,String paterno,String materno,String curp,String clues,String cedula,String usuario,String contra,Boolean estatus) {
		this.id=id;
		this.nombre=nombre;
		this.paterno=paterno;
		this.materno=materno;
		this.curp=curp;
		this.clues=clues;
		this.cedula=cedula;
		this.usuario=usuario;
		this.contra=contra;
		this.estatus=estatus;
	}


	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContra() {
		return contra;
	}

	public void setContra(String contra) {
		this.contra = contra;
	}

	public boolean getEstatus() {
		return estatus;
	}

	public void setEstatus(Boolean estatus) {
		this.estatus = estatus;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPaterno() {
		return paterno;
	}

	public void setPaterno(String paterno) {
		this.paterno = paterno;
	}

	public String getMaterno() {
		return materno;
	}

	public void setMaterno(String materno) {
		this.materno = materno;
	}

	public String getCurp() {
		return curp;
	}

	public void setCurp(String curp) {
		this.curp = curp;
	}

	public String getClues() {
		return clues;
	}

	public void setClues(String clues) {
		this.clues = clues;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	
	
	
}
