package comun.entidades;

public class Hidratacion {
	private String id, nombre;
	private boolean estatus;
	public Hidratacion() {}
	public Hidratacion(String id,String nombre, boolean estatus) {
		this.setId(id);
		this.setNombre(nombre);
		this.setEstatus(estatus);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public boolean isEstatus() {
		return estatus;
	}
	public void setEstatus(boolean estatus) {
		this.estatus = estatus;
	}

}
