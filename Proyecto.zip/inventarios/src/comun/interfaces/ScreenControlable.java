package comun.interfaces;

import vista.Main;

public interface ScreenControlable {
	public void setMainApp(Main mainApp);
}
