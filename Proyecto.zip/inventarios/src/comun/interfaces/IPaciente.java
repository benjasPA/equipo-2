package comun.interfaces;

import java.sql.SQLException;
import java.util.List;

import comun.entidades.Paciente;

public interface IPaciente {
	
	public  boolean agregar(Paciente Paciente) throws ClassNotFoundException,	
	InstantiationException, 
	IllegalAccessException, 
	SQLException;

	public boolean  actualizar(Paciente Paciente) throws ClassNotFoundException, 
			InstantiationException,
			IllegalAccessException, 
			SQLException;
	
	void eliminar(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException;
	
	public List<Paciente> listar() throws ClassNotFoundException,
	InstantiationException, 
	IllegalAccessException, 
	SQLException;

	public boolean guardar() throws ClassNotFoundException,
	InstantiationException, 
	IllegalAccessException, 
	SQLException;

	public List<Paciente> listarB() throws ClassNotFoundException,
	InstantiationException, 
	IllegalAccessException, 
	SQLException;
	
	void restaurar(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException;
	

}
