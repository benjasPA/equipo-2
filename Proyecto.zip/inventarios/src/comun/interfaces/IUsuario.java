package comun.interfaces;

import java.sql.SQLException;
import java.util.List;

import comun.entidades.Usuario;

public interface IUsuario {
	
	public  boolean agregar(Usuario Usuario) throws ClassNotFoundException,	
	InstantiationException, 
	IllegalAccessException, 
	SQLException;

	public boolean  actualizar(Usuario Usuario) throws ClassNotFoundException, 
			InstantiationException,
			IllegalAccessException, 
			SQLException;
	
	void eliminar(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException;
	
	public List<Usuario> listar() throws ClassNotFoundException,
	InstantiationException, 
	IllegalAccessException, 
	SQLException;

	public boolean guardar() throws ClassNotFoundException,
	InstantiationException, 
	IllegalAccessException, 
	SQLException;

	public List<Usuario> listarB() throws ClassNotFoundException,
	InstantiationException, 
	IllegalAccessException, 
	SQLException;
	
	void restaurar(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException;
	

}
