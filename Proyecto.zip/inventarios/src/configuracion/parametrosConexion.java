package configuracion;

	import java.io.File;
	import java.io.FileInputStream;
	import java.util.Properties;

	public class parametrosConexion {
			 
			private String ip;  
			private String puerto;  
			private String basedatos;  
			private String usuario;  
			private String contrasenia;  
			private String PATH="conexion.properties";
			public String getIp() {
				return ip;
			}
			public void setIp(String ip) {
				this.ip = ip;
			}
			public String getBasedatos() {
				return basedatos;
			}
			public void setBasedatos(String basedatos) {
				this.basedatos = basedatos;
			}
			public String getPuerto() {
				return puerto;
			}
			public void setPuerto(String puerto) {
				this.puerto = puerto;
			}
			public String getUsuario() {
				return usuario;
			}
			public void setUsuario(String usuario) {
				this.usuario = usuario;
			}
			public String getContrasenia() {
				return contrasenia;
			}
			public void setContrasenia(String contrasenia) {
				this.contrasenia = contrasenia;
			}
			public String getPATH() {
				return PATH;
			}
			public void setPATH(String pATH) {
				PATH = pATH;
			} 
			public void asignarParametros(){
				try{   
				Properties propiedades = new Properties();
				
				//indicamos la ruta del archivo    
						
				FileInputStream entrada = new FileInputStream(new File(PATH)); 
				
				//cargamos el archivo   
				
				propiedades.load(entrada);  
				
				//asignamos a los atributos los valores contenidos en el  archivo. 
				
				contrasenia=propiedades.getProperty("contrasenia");   
				usuario=propiedades.getProperty("usuario");  
				basedatos=propiedades.getProperty("basedatos"); 
				ip=propiedades.getProperty("ip");  
				puerto=propiedades.getProperty("puerto");  
				
				}catch(Exception e){   
					
				System.out.println(e.getMessage()); 
				System.out.println("Base 1"); 
				}  
			}
			
			
	}
