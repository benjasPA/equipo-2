package vista;

import comun.interfaces.ScreenControlable;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Main extends Application {
	private Stage mainStage;
	private Group mainScene;

	public static String menu="fxml/menu.fxml";
	public static String principal="fxml/principal.fxml";
	public static String doctores="fxml/usuarios.fxml";
	public static String programas="fxml/programas.fxml";
	public static String atencion="fxml/Atencion.fxml";
	public static String paciente="fxml/paciente.fxml";
	public static String controlpre="fxml/controlpre.fxml";
	public static String estadonutricion="fxml/estadoNutricion.fxml";
	public static String nivel="fxml/nivel.fxml";
	public static String tratamiento="fxml/tratamiento.fxml";
	public static String hidratacion="fxml/hidratacion.fxml";
	public static String dh="fxml/dh.fxml";
	public static String metodos="fxml/metodos.fxml";
	public static String deteccion="fxml/deteccion.fxml";
	public static String otro="fxml/otro.fxml";
	public static String estado="fxml/estado.fxml";
	public static String municipio="fxml/municipio.fxml";
	public static String localidad="fxml/localidad.fxml";
	public static String enfermedades="fxml/enfermedades.fxml";
	public static String historial="fxml/historial.fxml";
	public static String nueva="fxml/nueva.fxml";
	public static String pacientes="fxml/Pacientes.fxml";
	public static String Login="fxml/Login.fxml";
	public static String usuariosb="fxml/usuariosB.fxml";
	public static String pacientesb="fxml/pacientesB.fxml";
	
	
	
	
	public boolean cargarVentana(String archivoFXML) {
		try{
			FXMLLoader myLoder = new FXMLLoader(getClass().getResource(archivoFXML));
			AnchorPane screen = (AnchorPane) myLoder.load();
			if(menu.equals(archivoFXML) || mainScene.getChildren().isEmpty()) {
				mainScene.getChildren().add(screen);
			}else{
				mainScene.getChildren().remove(0);
				mainScene.getChildren().add(0,screen);
			}
			ScreenControlable myScreenControlable=((ScreenControlable) myLoder.getController());
			myScreenControlable.setMainApp(this);
			return true;
		}catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
	}
	@Override
	public void start(Stage stage) {
		Group root = new Group();
		this.mainStage=stage;
        this.mainScene=root;
        this.cargarVentana(principal);
        this.cargarVentana(menu);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
